import os
from time import sleep
import time


timer = os.getenv('TIMER')
if not timer :
    timer = 1
timer = float(timer)

tic = True
while True:
    if tic :
        print(f"{time.time()} Tic")
        tic = False
    else :
        print(f"{time.time()} Tac")
        tic = True
    sleep(timer)