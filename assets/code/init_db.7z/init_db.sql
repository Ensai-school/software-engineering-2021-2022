DROP TABLE IF EXISTS statistique_monstre CASCADE;
DROP TABLE IF EXISTS monstre CASCADE;
DROP TABLE IF EXISTS type_monstre CASCADE;

DROP SEQUENCE IF EXISTS id_monstre_seq ;
DROP SEQUENCE IF EXISTS id_type_monstre_seq ;
CREATE SEQUENCE id_monstre_seq ;
CREATE SEQUENCE id_type_monstre_seq ;


CREATE TABLE type_monstre (
	id_type_monstre integer NOT NULL DEFAULT nextval
	('id_type_monstre_seq'::regclass) PRIMARY KEY,
	label_type_monstre text
);

INSERT INTO type_monstre (id_type_monstre, label_type_monstre) VALUES
(1, 'aberration'),
(2, 'humanoïde'),
(3,'animal'),
(4,'dragon'),
(5,'créature magique'),
(6,'mort-vivant'),
(7,'créature artificielle'),
(8, 'plante'),
(9, 'extérieur'),
(10, 'vase');

CREATE TABLE monstre (
	id_monstre integer NOT NULL DEFAULT nextval
	('id_monstre_seq'::regclass),
    nom text COLLATE pg_catalog."default" NOT NULL,
    description text COLLATE pg_catalog."default",
    type_monstre integer,
    CONSTRAINT monstre_pkey PRIMARY KEY (id_monstre),
    CONSTRAINT monstre_nom_key UNIQUE (nom),
    CONSTRAINT monstre_type_monstre_fkey FOREIGN KEY (type_monstre)
        REFERENCES public.type_monstre (id_type_monstre) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

INSERT INTO monstre (id_monstre,nom, description, type_monstre) VALUES
(1,'grizzly', 'Les puissants muscles qu’on voit bouger sous la fourrure brune de cet ours imposant laissent présager de sa rapidité et de sa force.', 2),
(2,'objet animé', 'Les os enfermés dans la cage s’entrechoquent quand sesjambes de chaînes s’animent et qu’elle part en quête de nouveaux prisonniers.', 7),
(3,'farfadet','Ce petit humanoïde aux oreilles pointues, aux yeux verts etau sourire sadique. Il tient une bouteille dans une main et un gourdin dans l’autre.', 5),
(4,'fleur de lune','Une gueule grand ouverte, prête à avaler une victime, setient au sommet d’un tronc difforme parsemé de bourgeons boursouflés.',8),
(5,'planétar','Ce grand humanoïde musclé et chauve possède une peau couleurd’émeraude et deux paires d’ailes aux plumes brillantes.',9),
(6,'gobelin','La large tête disgracieuse de cet humanoïde d’à peine un mètresemble totalement disproportionnée par rapport à son corps maigrelet.',2),
(7,'babau','Cette créature émaciée ressemble à un squelette d’humain cornurecouvert d’une fine peau de cuir huileux qui lui colle aux os.',9),
(8,'hydre','Plusieurs têtes de serpent visiblement fâchées s’élèvent du corps serpentin de ce monstre terrifiant.',5),
(9,'couleur tombée du ciel','Une étrange lueur, semblable à aucune autre,illumine soudain les lieux, apportant avec elle une impression étouffante de malveillance latente.',10),
(10,'jorôgumo','Huit grandes pattes d’araignée toutes grêles, couvertes detouffes de poils noirs épais, sortent du dos de cette femme aux cheveux noirs, par ailleurs très jolie.',2),
(11,'cristal carnivore','Les facettes de cette formation cristalline semodifient et vibrent, comme en signe d’anticipation.',10),
(12,'cthulhu','Cette gigantesque impossibilité, qui n’est ni pieuvre nidragon ni un géant mais quelque chose de bien pire, doit sûrement annoncer la fin des temps.',1),
(13,'tarasque','Comme un dinosaure, ce gigantesque reptile domine tout ce qui l’entoure. Il n’est que dents, cornes, griffes et queue épineuse.',5),
(14,'licorne','Cette magnifique bête semblable à un cheval blanc a unebarbiche de chèvre et une unique et longue corne d’ivoire sur le front.',5),
(15,'dévoreur d''intellect','Le corps de cette créature sans tête ressemble à un gros cerveau gluant possédant quatre petites pattes griffues pour seuls membres.',1),
(16,'mage mécanique','Cette créature artificielle sans visage est dotéed’une baguette de cristal incrustée dans la poitrine. Elle crépite d’énergie magique.',7),
(17,'yuki-onna','Cette belle femme au visage triste porte une robe ornée dejolis motifs et elle est entourée d’une masse de neige tourbillonnante.',6),
(18,'revenant','Un cadavre déformé et mutilé s’avance lourdement. Il tend ses doigts osseux et affûtés. Ses intentions maléfiques sont évidentes.',6),
(19,'dragon impérial du ciel','Pourtant dépourvu d’ailes, ce dragon sillonne le ciel en serpentant avec grâce, ses écailles réfléchissant les nuances changeantes des cieux.',4);

CREATE TABLE statistique_monstre
(
    id_monstre integer NOT NULL,
    force integer,
    magie integer,
    agilite integer,
    defense integer,
    points_de_vie integer,
    CONSTRAINT statistique_monstre_pkey PRIMARY KEY (id_monstre),
    CONSTRAINT statistique_monstre_id_monstre_fkey FOREIGN KEY (id_monstre)
        REFERENCES public.monstre (id_monstre) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

INSERT INTO statistique_monstre (id_monstre, force, magie, agilite, defense, points_de_vie) VALUES
(1,60,0,20,50,1500),
(2,30,0,10,20,400),
(3,5,30,30,20,300),
(4,15,15,15,15,300),
(5,100,100,50,100,3000),
(6,20,0,10,20,200),
(7,40,50,40,30,800),
(8,70,0,20,80,5000),
(9,50,30,0,45,1250),
(10,100,30,100,80,600),
(11,20,50,20,100,450),
(12,800,800,800,800,10000),
(13,1500,1500,300,1500,20000),
(14,60,150,50,50,400),
(15,30,100,80,50,163),
(16,50,150,30,80,480),
(17,80,120,180,65,190),
(18,50,0,30,80,1000),
(19,600,600,600,600,7000);

ALTER SEQUENCE id_monstre_seq RESTART WITH 20;
ALTER SEQUENCE id_type_monstre_seq RESTART WITH 11;

CREATE EXTENSION IF NOT EXISTS pg_trgm;

